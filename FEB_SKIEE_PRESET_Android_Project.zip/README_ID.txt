FEB SKIEE PRESET - PROYEK ANDROID AWAL

Isi:
- Proyek sumber Android (Kotlin)
- Nama aplikasi: FEB SKIEE PRESET
- applicationId: com.febskiee.preset
- Minimum Android: 6.0 (API 23)
- Target SDK: 35

Fitur yang ada pada kerangka awal:
1. Kolom untuk menempel tautan TikTok.
2. Tombol membuka tautan video.
3. Tombol memilih video dari penyimpanan HP.
4. Tombol membuka Alight Motion jika terpasang.

PENTING:
Ini BUKAN file APK dan belum dikompilasi atau diuji pada perangkat.
Analisis video TikTok otomatis, ekstraksi efek/keyframe, pembuatan file proyek Alight Motion,
dan tautan impor langsung BELUM dibuat. Fitur tersebut membutuhkan backend/AI dan
implementasi format proyek Alight Motion yang valid. Jangan menganggap tombol pembuka
video sebagai fitur analisis preset.

Cara build:
Buka folder proyek ini dengan Android Studio pada komputer, tunggu Gradle sync,
lalu pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
Untuk hasil yang dapat dipasang, uji APK di perangkat Android 14.
