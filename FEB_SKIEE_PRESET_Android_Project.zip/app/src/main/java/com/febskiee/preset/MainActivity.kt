package com.febskiee.preset

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface

class MainActivity : Activity() {
    private val red = Color.rgb(226, 28, 43)
    private lateinit var linkInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8,8,8)
        window.navigationBarColor = Color.rgb(8,8,8)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(8,8,8))
        }

        val brand = TextView(this).apply {
            text = "FEB SKIEE"
            textSize = 28f
            setTextColor(red)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "PRESET FINDER"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())

        val instruction = TextView(this).apply {
            text = "\nTempel tautan video TikTok"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        root.addView(instruction, matchWrap())

        linkInput = EditText(this).apply {
            hint = "https://www.tiktok.com/@..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(30, 30, 30))
        }
        root.addView(linkInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 10 })

        addButton(root, "BUKA VIDEO TIKTOK") { openTikTok() }
        addButton(root, "PILIH VIDEO DARI HP") { chooseVideo() }
        addButton(root, "BUKA ALIGHT MOTION") { openAlightMotion() }

        status = TextView(this).apply {
            text = "\nStatus: siap"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        root.addView(status, matchWrap())

        val note = TextView(this).apply {
            text = "\nCatatan: versi awal ini adalah alat pembuka tautan dan pemilih video. Analisis otomatis TikTok serta pembuatan tautan proyek Alight Motion belum tersedia dan memerlukan backend serta format proyek yang valid."
            textSize = 12f
            setTextColor(Color.rgb(170,170,170))
        }
        root.addView(note, matchWrap())

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            textSize = 14f
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 14 })
    }

    private fun openTikTok() {
        val raw = linkInput.text.toString().trim()
        if (raw.isEmpty()) {
            status.text = "Status: masukkan tautan TikTok terlebih dahulu."
            return
        }
        val uri = Uri.parse(raw)
        if (uri.scheme != "https" && uri.scheme != "http") {
            status.text = "Status: tautan harus diawali http:// atau https://"
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            status.text = "Status: tautan dibuka. Video belum dianalisis otomatis."
        } catch (_: Exception) {
            status.text = "Status: tautan tidak dapat dibuka."
        }
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "video/*" }
        startActivityForResult(Intent.createChooser(intent, "Pilih video"), 100)
    }

    @Deprecated("Deprecated by Android but retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            status.text = "Status: video dipilih. Analisis otomatis belum diaktifkan."
        }
    }

    private fun openAlightMotion() {
        val launch = packageManager.getLaunchIntentForPackage("com.alightcreative.motion")
        if (launch != null) {
            startActivity(launch)
        } else {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.alightcreative.motion")))
            } catch (_: ActivityNotFoundException) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.alightcreative.motion")))
            }
        }
    }
}
